AUTOCLICKER_TEXT = """
                         .▄▄ · 
                ██  ▄█▀▄ ▐█ ▀. 
                ▐█·▐█▌.▐▌▄▀▀▀█▄
                ▐█▌▐█▌.▐▌▐█▄ ▐█
                ▀▀▀ ▀█▄▀  ▀▀▀▀ 

             ---iOs Team's 2024---
                
                """

CREDITS = "\033[34mOriginal: https://github.com/iOsReal/Blum-Clicker\033[0m"
DONATE_TEXT = "\033[1;33;48mDonate here (ETH):\033[1;37;0m 0x227c47f8668dce0285321a842b94e2b2b8af56ca" \
              "\n\033[1;33;48mDonate here (USDT):\033[1;37;0m TNboQVbS4tbEPyU9vYVQpynZZLTHhMRj4q\n"
WINDOW_NOT_FOUND = "Blum window not found! Please open it, and restart the program."
